from django.utils import timezone
from django.shortcuts import render

from accounts.decorators import role_required
from children.models import ChildProfile
from immunizations.models import ImmunizationRecord
from appointments.models import Appointment


@role_required("admin", "doctor", "nurse")
def analytics_dashboard(request):
    total_children = ChildProfile.objects.count()

    immunizations_completed = ImmunizationRecord.objects.filter(
        status=ImmunizationRecord.STATUS_COMPLETED
    ).count()
    immunizations_scheduled = ImmunizationRecord.objects.filter(
        status=ImmunizationRecord.STATUS_SCHEDULED
    ).count()
    immunizations_missed = ImmunizationRecord.objects.filter(
        status=ImmunizationRecord.STATUS_MISSED
    ).count()

    upcoming_appointments = Appointment.objects.filter(
        appointment_date__gte=timezone.now(),
        status__in=[Appointment.STATUS_PENDING, Appointment.STATUS_CONFIRMED],
    ).count()
    completed_appointments = Appointment.objects.filter(
        status=Appointment.STATUS_COMPLETED
    ).count()

    context = {
        "total_children": total_children,
        "immunizations_completed": immunizations_completed,
        "immunizations_scheduled": immunizations_scheduled,
        "immunizations_missed": immunizations_missed,
        "upcoming_appointments": upcoming_appointments,
        "completed_appointments": completed_appointments,
    }
    return render(request, "reports/analytics_dashboard.html", context)
