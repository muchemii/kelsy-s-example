from django.conf import settings
from django.db import models


class ChatMessage(models.Model):
    """One exchange between a user and the Toto Care Assistant."""

    user = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.CASCADE)
    question = models.TextField()
    answer = models.TextField()
    created_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        ordering = ["-created_at"]

    def __str__(self):
        return f"{self.user} asked: {self.question[:50]}"
