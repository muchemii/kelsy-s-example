from django.urls import path
from . import views

app_name = "assistant"

urlpatterns = [
    path("", views.assistant_chat, name="assistant_chat"),
]
