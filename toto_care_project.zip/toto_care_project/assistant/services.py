"""
The Toto Care Assistant.

This wraps the OpenAI API so the rest of the project only has to call
ask_assistant(question). The assistant is instructed to give general
pediatric healthcare education and to always recommend seeing a doctor
or nurse for anything that could be serious (see FR-04 in the SRS).
"""

from django.conf import settings
from openai import OpenAI

SYSTEM_PROMPT = (
    "You are the Toto Care Assistant, a friendly helper inside a pediatric "
    "healthcare management system used in Kenya. You help parents and "
    "guardians with general child healthcare education: immunization "
    "schedules, common childhood illnesses, nutrition, and developmental "
    "milestones. You are not a doctor. Keep answers short and simple. "
    "Always remind the user to consult a doctor or nurse for anything "
    "urgent, serious, or outside general education, and never give a "
    "definite diagnosis."
)


def ask_assistant(question):
    """Send a question to OpenAI and return the assistant's reply as text.

    If no API key has been configured, a helpful placeholder message is
    returned instead of raising an error, so the rest of the app still works.
    """
    if not settings.OPENAI_API_KEY:
        return (
            "The Toto Care Assistant is not configured yet. Add your "
            "OPENAI_API_KEY to the .env file to enable AI responses."
        )

    client = OpenAI(api_key=settings.OPENAI_API_KEY)

    response = client.chat.completions.create(
        model="gpt-4o-mini",
        messages=[
            {"role": "system", "content": SYSTEM_PROMPT},
            {"role": "user", "content": question},
        ],
    )

    return response.choices[0].message.content
