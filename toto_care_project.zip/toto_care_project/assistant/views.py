from django.contrib.auth.decorators import login_required
from django.shortcuts import render

from .models import ChatMessage
from .services import ask_assistant


@login_required
def assistant_chat(request):
    answer = None

    if request.method == "POST":
        question = request.POST.get("question", "").strip()
        if question:
            answer = ask_assistant(question)
            ChatMessage.objects.create(user=request.user, question=question, answer=answer)

    history = ChatMessage.objects.filter(user=request.user)[:20]
    return render(
        request,
        "assistant/assistant_chat.html",
        {"answer": answer, "history": history},
    )
