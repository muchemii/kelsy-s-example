from django.contrib import messages
from django.contrib.auth.decorators import login_required
from django.shortcuts import render, redirect, get_object_or_404

from .models import HealthJournalEntry
from .forms import HealthJournalEntryForm


@login_required
def journal_list(request):
    if request.user.is_parent():
        entries = HealthJournalEntry.objects.filter(child__parent=request.user)
    else:
        entries = HealthJournalEntry.objects.all()
    return render(request, "journal/journal_list.html", {"entries": entries})


@login_required
def journal_add(request):
    if request.method == "POST":
        form = HealthJournalEntryForm(request.POST, user=request.user)
        if form.is_valid():
            entry = form.save(commit=False)
            entry.recorded_by = request.user
            entry.save()
            messages.success(request, "Health journal entry added.")
            return redirect("journal:journal_list")
    else:
        form = HealthJournalEntryForm(user=request.user)

    return render(request, "journal/journal_form.html", {"form": form, "title": "Add Journal Entry"})


@login_required
def journal_detail(request, pk):
    entry = get_object_or_404(HealthJournalEntry, pk=pk)
    if request.user.is_parent() and entry.child.parent_id != request.user.id:
        messages.error(request, "You do not have permission to view this entry.")
        return redirect("journal:journal_list")
    return render(request, "journal/journal_detail.html", {"entry": entry})
