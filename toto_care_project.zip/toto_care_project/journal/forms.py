from django import forms
from .models import HealthJournalEntry
from children.models import ChildProfile


class HealthJournalEntryForm(forms.ModelForm):
    class Meta:
        model = HealthJournalEntry
        fields = ["child", "entry_date", "symptoms", "weight_kg", "height_cm", "notes"]
        widgets = {
            "entry_date": forms.DateInput(attrs={"type": "date"}),
            "symptoms": forms.Textarea(attrs={"rows": 2}),
            "notes": forms.Textarea(attrs={"rows": 3}),
        }

    def __init__(self, *args, user=None, **kwargs):
        super().__init__(*args, **kwargs)
        if user is not None and user.is_parent():
            self.fields["child"].queryset = ChildProfile.objects.filter(parent=user)
