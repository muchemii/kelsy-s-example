from django.urls import path
from . import views

app_name = "journal"

urlpatterns = [
    path("", views.journal_list, name="journal_list"),
    path("add/", views.journal_add, name="journal_add"),
    path("<int:pk>/", views.journal_detail, name="journal_detail"),
]
