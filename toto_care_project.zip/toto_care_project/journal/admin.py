from django.contrib import admin
from .models import HealthJournalEntry


@admin.register(HealthJournalEntry)
class HealthJournalEntryAdmin(admin.ModelAdmin):
    list_display = ["child", "entry_date", "recorded_by"]
