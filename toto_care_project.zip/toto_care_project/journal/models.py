from django.conf import settings
from django.db import models
from children.models import ChildProfile


class HealthJournalEntry(models.Model):
    """A note recorded about a child's health, added by a parent or a healthcare provider."""

    child = models.ForeignKey(
        ChildProfile, on_delete=models.CASCADE, related_name="journal_entries"
    )
    recorded_by = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.CASCADE)
    entry_date = models.DateField()
    symptoms = models.TextField(blank=True)
    weight_kg = models.DecimalField(max_digits=5, decimal_places=2, blank=True, null=True)
    height_cm = models.DecimalField(max_digits=5, decimal_places=2, blank=True, null=True)
    notes = models.TextField(blank=True)
    created_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        ordering = ["-entry_date"]

    def __str__(self):
        return f"Journal entry for {self.child.full_name} on {self.entry_date}"
