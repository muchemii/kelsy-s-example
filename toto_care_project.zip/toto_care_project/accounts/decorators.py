from django.contrib.auth.decorators import login_required, user_passes_test
from django.core.exceptions import PermissionDenied


def role_required(*allowed_roles):
    """
    Decorator that only allows users whose role is in allowed_roles.
    Example:
        @role_required("admin", "doctor")
        def some_view(request):
            ...
    """

    def check_role(user):
        if user.is_authenticated and user.role in allowed_roles:
            return True
        raise PermissionDenied("You do not have permission to view this page.")

    def decorator(view_func):
        return login_required(user_passes_test(check_role)(view_func))

    return decorator
