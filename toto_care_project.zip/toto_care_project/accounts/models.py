from django.contrib.auth.models import AbstractUser
from django.db import models


class User(AbstractUser):
    """
    Custom user model for Toto Care.

    Every user has a role. The role controls which parts of the system
    the user is allowed to use (see the role checks in each app's views).
    """

    ROLE_ADMIN = "admin"
    ROLE_DOCTOR = "doctor"
    ROLE_NURSE = "nurse"
    ROLE_PARENT = "parent"

    ROLE_CHOICES = [
        (ROLE_ADMIN, "Administrator"),
        (ROLE_DOCTOR, "Doctor"),
        (ROLE_NURSE, "Nurse"),
        (ROLE_PARENT, "Parent or Guardian"),
    ]

    role = models.CharField(max_length=20, choices=ROLE_CHOICES, default=ROLE_PARENT)
    phone_number = models.CharField(max_length=20, blank=True)

    def is_admin(self):
        return self.role == self.ROLE_ADMIN

    def is_doctor(self):
        return self.role == self.ROLE_DOCTOR

    def is_nurse(self):
        return self.role == self.ROLE_NURSE

    def is_parent(self):
        return self.role == self.ROLE_PARENT

    def is_healthcare_provider(self):
        return self.role in (self.ROLE_DOCTOR, self.ROLE_NURSE)

    def __str__(self):
        return f"{self.get_full_name() or self.username} ({self.get_role_display()})"
