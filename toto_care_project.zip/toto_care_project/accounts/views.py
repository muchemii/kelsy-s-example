from django.contrib import messages
from django.contrib.auth import login
from django.contrib.auth.decorators import login_required
from django.shortcuts import render, redirect, get_object_or_404

from accounts.decorators import role_required
from .forms import RegisterForm, UserEditForm
from .models import User


def register(request):
    if request.method == "POST":
        form = RegisterForm(request.POST)
        if form.is_valid():
            user = form.save()
            login(request, user)
            messages.success(request, "Account created successfully. Welcome to Toto Care.")
            return redirect("accounts:dashboard")
    else:
        form = RegisterForm()

    return render(request, "accounts/register.html", {"form": form})


@login_required
def dashboard(request):
    """Show a different dashboard template depending on the user's role."""
    user = request.user

    if user.is_admin():
        template = "accounts/dashboard_admin.html"
    elif user.is_doctor() or user.is_nurse():
        template = "accounts/dashboard_provider.html"
    else:
        template = "accounts/dashboard_parent.html"

    return render(request, template)


@role_required("admin")
def user_list(request):
    users = User.objects.all().order_by("first_name")
    return render(request, "accounts/user_list.html", {"users": users})


@role_required("admin")
def user_edit(request, pk):
    user = get_object_or_404(User, pk=pk)

    if request.method == "POST":
        form = UserEditForm(request.POST, instance=user)
        if form.is_valid():
            form.save()
            messages.success(request, "User account updated.")
            return redirect("accounts:user_list")
    else:
        form = UserEditForm(instance=user)

    return render(request, "accounts/user_form.html", {"form": form, "title": "Edit User"})
