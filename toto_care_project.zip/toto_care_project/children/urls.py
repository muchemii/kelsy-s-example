from django.urls import path
from . import views

app_name = "children"

urlpatterns = [
    path("", views.child_list, name="child_list"),
    path("add/", views.child_add, name="child_add"),
    path("<int:pk>/", views.child_detail, name="child_detail"),
    path("<int:pk>/edit/", views.child_edit, name="child_edit"),
]
