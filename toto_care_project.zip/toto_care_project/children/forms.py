from django import forms
from .models import ChildProfile


class ChildProfileForm(forms.ModelForm):
    class Meta:
        model = ChildProfile
        fields = [
            "full_name",
            "date_of_birth",
            "gender",
            "blood_group",
            "known_allergies",
            "photo",
        ]
        widgets = {
            "date_of_birth": forms.DateInput(attrs={"type": "date"}),
            "known_allergies": forms.Textarea(attrs={"rows": 3}),
        }
