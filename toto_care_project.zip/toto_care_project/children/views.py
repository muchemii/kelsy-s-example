from django.contrib import messages
from django.contrib.auth.decorators import login_required
from django.shortcuts import render, redirect, get_object_or_404

from .models import ChildProfile
from .forms import ChildProfileForm


def _can_view_child(user, child):
    """A parent can only view their own children. Staff can view all children."""
    if user.is_healthcare_provider() or user.is_admin():
        return True
    return child.parent_id == user.id


@login_required
def child_list(request):
    if request.user.is_parent():
        children = ChildProfile.objects.filter(parent=request.user)
    else:
        children = ChildProfile.objects.all()
    return render(request, "children/child_list.html", {"children": children})


@login_required
def child_add(request):
    if not request.user.is_parent():
        messages.error(request, "Only parents/guardians can register a child.")
        return redirect("children:child_list")

    if request.method == "POST":
        form = ChildProfileForm(request.POST, request.FILES)
        if form.is_valid():
            child = form.save(commit=False)
            child.parent = request.user
            child.save()
            messages.success(request, "Child profile created successfully.")
            return redirect("children:child_detail", pk=child.pk)
    else:
        form = ChildProfileForm()

    return render(request, "children/child_form.html", {"form": form, "title": "Add Child"})


@login_required
def child_detail(request, pk):
    child = get_object_or_404(ChildProfile, pk=pk)
    if not _can_view_child(request.user, child):
        messages.error(request, "You do not have permission to view this child's profile.")
        return redirect("children:child_list")
    return render(request, "children/child_detail.html", {"child": child})


@login_required
def child_edit(request, pk):
    child = get_object_or_404(ChildProfile, pk=pk)
    if not _can_view_child(request.user, child):
        messages.error(request, "You do not have permission to edit this child's profile.")
        return redirect("children:child_list")

    if request.method == "POST":
        form = ChildProfileForm(request.POST, request.FILES, instance=child)
        if form.is_valid():
            form.save()
            messages.success(request, "Child profile updated.")
            return redirect("children:child_detail", pk=child.pk)
    else:
        form = ChildProfileForm(instance=child)

    return render(request, "children/child_form.html", {"form": form, "title": "Edit Child"})
