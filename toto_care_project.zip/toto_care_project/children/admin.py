from django.contrib import admin
from .models import ChildProfile


@admin.register(ChildProfile)
class ChildProfileAdmin(admin.ModelAdmin):
    list_display = ["full_name", "date_of_birth", "gender", "parent"]
    search_fields = ["full_name"]
