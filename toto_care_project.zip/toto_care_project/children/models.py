from django.conf import settings
from django.db import models


class ChildProfile(models.Model):
    """A child's profile, registered and managed by a parent/guardian."""

    GENDER_MALE = "M"
    GENDER_FEMALE = "F"
    GENDER_CHOICES = [(GENDER_MALE, "Male"), (GENDER_FEMALE, "Female")]

    parent = models.ForeignKey(
        settings.AUTH_USER_MODEL,
        on_delete=models.CASCADE,
        related_name="children",
        limit_choices_to={"role": "parent"},
    )
    full_name = models.CharField(max_length=150)
    date_of_birth = models.DateField()
    gender = models.CharField(max_length=1, choices=GENDER_CHOICES)
    blood_group = models.CharField(max_length=5, blank=True)
    known_allergies = models.TextField(blank=True)
    photo = models.ImageField(upload_to="child_photos/", blank=True, null=True)
    created_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        ordering = ["full_name"]

    def age_in_months(self):
        from datetime import date
        today = date.today()
        months = (today.year - self.date_of_birth.year) * 12
        months += today.month - self.date_of_birth.month
        return months

    def __str__(self):
        return self.full_name
