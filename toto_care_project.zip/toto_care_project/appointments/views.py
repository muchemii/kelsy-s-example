from django.contrib import messages
from django.contrib.auth.decorators import login_required
from django.shortcuts import render, redirect, get_object_or_404

from .models import Appointment
from .forms import AppointmentRequestForm, AppointmentUpdateForm


@login_required
def appointment_list(request):
    if request.user.is_parent():
        appointments = Appointment.objects.filter(child__parent=request.user)
    elif request.user.is_healthcare_provider():
        appointments = Appointment.objects.all()
    else:
        appointments = Appointment.objects.all()
    return render(request, "appointments/appointment_list.html", {"appointments": appointments})


@login_required
def appointment_request(request):
    if not request.user.is_parent():
        messages.error(request, "Only parents/guardians can request an appointment.")
        return redirect("appointments:appointment_list")

    if request.method == "POST":
        form = AppointmentRequestForm(request.POST, user=request.user)
        if form.is_valid():
            appointment = form.save(commit=False)
            appointment.requested_by = request.user
            appointment.save()
            messages.success(request, "Appointment request submitted.")
            return redirect("appointments:appointment_list")
    else:
        form = AppointmentRequestForm(user=request.user)

    return render(
        request, "appointments/appointment_form.html", {"form": form, "title": "Request Appointment"}
    )


@login_required
def appointment_update(request, pk):
    appointment = get_object_or_404(Appointment, pk=pk)
    if request.user.is_parent():
        messages.error(request, "Only staff can update an appointment.")
        return redirect("appointments:appointment_list")

    if request.method == "POST":
        form = AppointmentUpdateForm(request.POST, instance=appointment)
        if form.is_valid():
            form.save()
            messages.success(request, "Appointment updated.")
            return redirect("appointments:appointment_list")
    else:
        form = AppointmentUpdateForm(instance=appointment)

    return render(
        request, "appointments/appointment_form.html", {"form": form, "title": "Update Appointment"}
    )
