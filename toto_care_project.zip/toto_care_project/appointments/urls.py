from django.urls import path
from . import views

app_name = "appointments"

urlpatterns = [
    path("", views.appointment_list, name="appointment_list"),
    path("request/", views.appointment_request, name="appointment_request"),
    path("<int:pk>/update/", views.appointment_update, name="appointment_update"),
]
