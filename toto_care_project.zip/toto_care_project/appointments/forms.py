from django import forms
from .models import Appointment
from children.models import ChildProfile
from accounts.models import User


class AppointmentRequestForm(forms.ModelForm):
    """Used by a parent to request an appointment for their child."""

    class Meta:
        model = Appointment
        fields = ["child", "reason", "appointment_date"]
        widgets = {
            "appointment_date": forms.DateTimeInput(attrs={"type": "datetime-local"}),
        }

    def __init__(self, *args, user=None, **kwargs):
        super().__init__(*args, **kwargs)
        if user is not None:
            self.fields["child"].queryset = ChildProfile.objects.filter(parent=user)


class AppointmentUpdateForm(forms.ModelForm):
    """Used by staff to assign a provider, confirm, or update an appointment."""

    class Meta:
        model = Appointment
        fields = ["assigned_to", "appointment_date", "status", "notes"]
        widgets = {
            "appointment_date": forms.DateTimeInput(attrs={"type": "datetime-local"}),
            "notes": forms.Textarea(attrs={"rows": 3}),
        }

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.fields["assigned_to"].queryset = User.objects.filter(role__in=["doctor", "nurse"])
