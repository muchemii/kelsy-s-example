from django.contrib import admin
from .models import Appointment


@admin.register(Appointment)
class AppointmentAdmin(admin.ModelAdmin):
    list_display = ["child", "reason", "appointment_date", "status", "assigned_to"]
    list_filter = ["status"]
