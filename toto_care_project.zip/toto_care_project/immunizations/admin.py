from django.contrib import admin
from .models import ImmunizationRecord


@admin.register(ImmunizationRecord)
class ImmunizationRecordAdmin(admin.ModelAdmin):
    list_display = ["child", "vaccine_name", "dose_number", "scheduled_date", "status"]
    list_filter = ["status"]
