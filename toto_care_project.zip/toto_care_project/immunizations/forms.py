from django import forms
from .models import ImmunizationRecord


class ImmunizationRecordForm(forms.ModelForm):
    class Meta:
        model = ImmunizationRecord
        fields = [
            "child",
            "vaccine_name",
            "dose_number",
            "scheduled_date",
            "date_administered",
            "status",
            "notes",
        ]
        widgets = {
            "scheduled_date": forms.DateInput(attrs={"type": "date"}),
            "date_administered": forms.DateInput(attrs={"type": "date"}),
            "notes": forms.Textarea(attrs={"rows": 3}),
        }
