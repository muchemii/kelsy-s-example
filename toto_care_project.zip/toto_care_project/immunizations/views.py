from django.contrib import messages
from django.contrib.auth.decorators import login_required
from django.shortcuts import render, redirect, get_object_or_404

from accounts.decorators import role_required
from children.models import ChildProfile
from .models import ImmunizationRecord
from .forms import ImmunizationRecordForm


@login_required
def immunization_list(request):
    if request.user.is_parent():
        records = ImmunizationRecord.objects.filter(child__parent=request.user)
    else:
        records = ImmunizationRecord.objects.all()
    return render(request, "immunizations/immunization_list.html", {"records": records})


@role_required("admin", "doctor", "nurse")
def immunization_add(request):
    if request.method == "POST":
        form = ImmunizationRecordForm(request.POST)
        if form.is_valid():
            record = form.save(commit=False)
            record.administered_by = request.user
            record.save()
            messages.success(request, "Immunization record saved.")
            return redirect("immunizations:immunization_list")
    else:
        form = ImmunizationRecordForm()

    return render(
        request,
        "immunizations/immunization_form.html",
        {"form": form, "title": "Add Immunization Record"},
    )


@role_required("admin", "doctor", "nurse")
def immunization_edit(request, pk):
    record = get_object_or_404(ImmunizationRecord, pk=pk)

    if request.method == "POST":
        form = ImmunizationRecordForm(request.POST, instance=record)
        if form.is_valid():
            form.save()
            messages.success(request, "Immunization record updated.")
            return redirect("immunizations:immunization_list")
    else:
        form = ImmunizationRecordForm(instance=record)

    return render(
        request,
        "immunizations/immunization_form.html",
        {"form": form, "title": "Edit Immunization Record"},
    )


@login_required
def immunization_for_child(request, child_id):
    child = get_object_or_404(ChildProfile, pk=child_id)
    if request.user.is_parent() and child.parent_id != request.user.id:
        messages.error(request, "You do not have permission to view this record.")
        return redirect("children:child_list")

    records = ImmunizationRecord.objects.filter(child=child)
    return render(
        request,
        "immunizations/immunization_list.html",
        {"records": records, "child": child},
    )
