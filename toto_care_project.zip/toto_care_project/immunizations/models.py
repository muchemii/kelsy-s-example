from django.conf import settings
from django.db import models
from children.models import ChildProfile


class ImmunizationRecord(models.Model):
    """A single vaccine dose record for a child."""

    STATUS_SCHEDULED = "scheduled"
    STATUS_COMPLETED = "completed"
    STATUS_MISSED = "missed"

    STATUS_CHOICES = [
        (STATUS_SCHEDULED, "Scheduled"),
        (STATUS_COMPLETED, "Completed"),
        (STATUS_MISSED, "Missed"),
    ]

    child = models.ForeignKey(
        ChildProfile, on_delete=models.CASCADE, related_name="immunizations"
    )
    vaccine_name = models.CharField(max_length=100)
    dose_number = models.PositiveIntegerField(default=1)
    scheduled_date = models.DateField()
    date_administered = models.DateField(blank=True, null=True)
    status = models.CharField(max_length=20, choices=STATUS_CHOICES, default=STATUS_SCHEDULED)
    administered_by = models.ForeignKey(
        settings.AUTH_USER_MODEL,
        on_delete=models.SET_NULL,
        blank=True,
        null=True,
        related_name="immunizations_given",
    )
    notes = models.TextField(blank=True)

    class Meta:
        ordering = ["scheduled_date"]

    def __str__(self):
        return f"{self.vaccine_name} (dose {self.dose_number}) - {self.child.full_name}"
