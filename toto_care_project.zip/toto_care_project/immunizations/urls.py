from django.urls import path
from . import views

app_name = "immunizations"

urlpatterns = [
    path("", views.immunization_list, name="immunization_list"),
    path("add/", views.immunization_add, name="immunization_add"),
    path("<int:pk>/edit/", views.immunization_edit, name="immunization_edit"),
    path("child/<int:child_id>/", views.immunization_for_child, name="immunization_for_child"),
]
