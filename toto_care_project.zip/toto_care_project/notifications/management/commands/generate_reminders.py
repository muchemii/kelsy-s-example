from django.core.management.base import BaseCommand
from notifications.services import generate_due_reminders


class Command(BaseCommand):
    help = "Generate smart reminder notifications for immunizations and appointments due soon."

    def handle(self, *args, **options):
        count = generate_due_reminders()
        self.stdout.write(self.style.SUCCESS(f"Created {count} new notification(s)."))
