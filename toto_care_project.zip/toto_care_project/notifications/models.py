from django.conf import settings
from django.db import models


class Notification(models.Model):
    """A reminder or alert shown to a user (e.g. an upcoming immunization or appointment)."""

    TYPE_IMMUNIZATION = "immunization"
    TYPE_APPOINTMENT = "appointment"
    TYPE_GENERAL = "general"

    TYPE_CHOICES = [
        (TYPE_IMMUNIZATION, "Immunization Reminder"),
        (TYPE_APPOINTMENT, "Appointment Reminder"),
        (TYPE_GENERAL, "General"),
    ]

    recipient = models.ForeignKey(
        settings.AUTH_USER_MODEL, on_delete=models.CASCADE, related_name="notifications"
    )
    notification_type = models.CharField(max_length=20, choices=TYPE_CHOICES, default=TYPE_GENERAL)
    message = models.CharField(max_length=255)
    is_read = models.BooleanField(default=False)
    created_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        ordering = ["-created_at"]

    def __str__(self):
        return self.message
