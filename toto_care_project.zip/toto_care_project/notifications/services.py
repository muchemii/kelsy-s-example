"""
Logic for generating the "smart reminder" notifications described in the
project report (upcoming immunizations and appointments).

This is called from a management command (see notifications/management/
commands/generate_reminders.py) which can be scheduled to run daily, e.g.
with a cron job or Windows Task Scheduler.
"""

from datetime import date, timedelta
from django.utils import timezone

from immunizations.models import ImmunizationRecord
from appointments.models import Appointment
from .models import Notification

REMINDER_WINDOW_DAYS = 3


def generate_due_reminders():
    """Create notifications for immunizations and appointments due soon.

    Returns the number of notifications created.
    """
    created_count = 0
    created_count += _generate_immunization_reminders()
    created_count += _generate_appointment_reminders()
    return created_count


def _generate_immunization_reminders():
    today = date.today()
    cutoff = today + timedelta(days=REMINDER_WINDOW_DAYS)

    due_soon = ImmunizationRecord.objects.filter(
        status=ImmunizationRecord.STATUS_SCHEDULED,
        scheduled_date__gte=today,
        scheduled_date__lte=cutoff,
    )

    created_count = 0
    for record in due_soon:
        parent = record.child.parent
        message = (
            f"{record.child.full_name} has {record.vaccine_name} "
            f"(dose {record.dose_number}) scheduled on {record.scheduled_date}."
        )
        already_sent = Notification.objects.filter(
            recipient=parent,
            notification_type=Notification.TYPE_IMMUNIZATION,
            message=message,
        ).exists()
        if not already_sent:
            Notification.objects.create(
                recipient=parent,
                notification_type=Notification.TYPE_IMMUNIZATION,
                message=message,
            )
            created_count += 1
    return created_count


def _generate_appointment_reminders():
    now = timezone.now()
    cutoff = now + timedelta(days=REMINDER_WINDOW_DAYS)

    due_soon = Appointment.objects.filter(
        status__in=[Appointment.STATUS_PENDING, Appointment.STATUS_CONFIRMED],
        appointment_date__gte=now,
        appointment_date__lte=cutoff,
    )

    created_count = 0
    for appointment in due_soon:
        parent = appointment.child.parent
        message = (
            f"{appointment.child.full_name} has an appointment ({appointment.reason}) "
            f"on {appointment.appointment_date:%Y-%m-%d %H:%M}."
        )
        already_sent = Notification.objects.filter(
            recipient=parent,
            notification_type=Notification.TYPE_APPOINTMENT,
            message=message,
        ).exists()
        if not already_sent:
            Notification.objects.create(
                recipient=parent,
                notification_type=Notification.TYPE_APPOINTMENT,
                message=message,
            )
            created_count += 1
    return created_count
